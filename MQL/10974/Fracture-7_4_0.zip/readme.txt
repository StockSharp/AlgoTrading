EUR/USD 5min or similar
Start with the settings in the set file provided. They return 400% for the month of June 2013.
I suggest you tweak the settings to your liking on the backtester before going live.
The only weakness in the EA is when there is a major trend change due to a News Release ( it handles typical high impact news releases fine )