HOW TO USE

- Copy Shuriken.ttf font file to C:\Windows\Fonts folder first.

- Shuriken Lite.mq4 goes in the experts folder of your MT4 directory.

- Restart MT4

- Place on a chart and input the magic numbers of your EA's trading on the account.

- Enjoy!